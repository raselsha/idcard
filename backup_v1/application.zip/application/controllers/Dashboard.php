<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
* 
*/
class Dashboard extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		if ($this->session->has_userdata('user')!='admin'){
			redirect('login');	
		}
		
	}

	public function index()
	{
		$data = array();
		$data['title'] = "Dashboard | Home";
		$data['page_title'] = "Dashboard";
		$data['content'] = $this->load->view('dashboard_v',$data,true);
		$this->load->view('main_v',$data);
	}

	public function search()
	{
		$search=$this->input->post('search',true);

		if ($search=='') {
			redirect('dashboard/students');
		}
		else{
			$result = $this->dashboard_m->search($search);
			if ($result) {
				redirect('dashboard/single_student/'.$result);
			}
			else{
				redirect('dashboard/students');
			}
		}
	}

	public function new_course()
	{
		$data = array();
		$data['title'] = "Dashboard | New course";
		$data['page_title'] = "Add new course";
		$data['content'] = $this->load->view('new_course_v',$data,true);
		$this->load->view('main_v',$data);
	}
	public function save_course()
	{
		$data = array();
		$result = $this->dashboard_m->save_course();
		$sdata = array();
		if ($result==1) {
			$sdata['message']='Data saved';
			$this->session->set_userdata($sdata);
			$data['content'] = $this->load->view('new_course_v',$data,true);
			redirect('dashboard/new_course');
		}
		else{
			$sdata['message']='Data not saved';
			$this->session->set_userdata($sdata);
			$data['content'] = $this->load->view('new_course_v',$data,true);
			redirect('dashboard/new_course');
		}
		$this->load->view('main_v',$data);
	}

	public function courses()
	{	$data = array();
		$data['title'] = "Dashboard | Courses";
		$data['page_title'] = "All Courses";
		$config['base_url'] = base_url('dashboard/courses');
		$config['per_page'] = 10;
		$config['total_rows'] = $this->db->get('courses')->num_rows();
		$this->pagination->initialize($config);
		$data['courses'] = $this->dashboard_m->courses($config['per_page'],$this->uri->segment(3));
		$data['content'] = $this->load->view('courses_v',$data,true);
		$this->load->view('main_v',$data);
	}

	public function single_course($id=null)
	{
		if ($id) {
			$data = array();
			$data['title'] = "Dashboard | Course details";
			$data['page_title'] = "Course details";
			$data['course'] = $this->dashboard_m->single_course($id);
			$data['content'] = $this->load->view('single_course_v',$data,true);
			$this->load->view('main_v',$data);
		}
		else{
			redirect('dashboard/courses');
		}
	}

	public function edit_course($id=null)
	{
		if ($id) {
			$data = array();
			$data['title'] = "Dashboard | Edit course";
			$data['page_title'] = "Edit course";
			$data['course'] = $this->dashboard_m->edit_course($id);
			$data['content'] = $this->load->view('edit_course_v',$data,true);
			$this->load->view('main_v',$data);
		}
		else{
			redirect('dashboard/courses');
		}
	}
	public function update_course($id=null)
	{
		if ($id) {
			$data = array();
			$result = $this->dashboard_m->update_course($id);
			$sdata = array();
			if ($result==1) {
				$sdata['message']='Data saved';
				$this->session->set_userdata($sdata);
				$data['content'] = $this->load->view('new_course_v',$data,true);
				redirect('dashboard/courses');
			}
			else{
				$sdata['message']='Data not saved';
				$this->session->set_userdata($sdata);
				$data['content'] = $this->load->view('new_course_v',$data,true);
				redirect('dashboard/courses');
			}
			$this->load->view('main_v',$data);
		}
		else{
			redirect('dashboard/courses');
		}
	}
	public function delete_course($id=null)
	{
		if ($id) {
			$sdata= array();
			$result=$this->dashboard_m->delete_course($id);
			if ($result==1) {
				$sdata['message']='Data deleted';
				$this->session->set_userdata($sdata);
				redirect('dashboard/courses');
			}
			else{
				$sdata['message']='Data cant\'be deleted';
				$this->session->set_userdata($sdata);
				redirect('dashboard/courses');
			}
		}
		else{
			redirect('dashboard/courses');
		}
	}
	public function new_student()
	{
		$data = array();
		$data['title'] = "Dashboard | New student";
		$data['page_title'] = "Add new student";
		$data['courses'] = $this->dashboard_m->courses();
		$data['content'] = $this->load->view('new_student_v',$data,true);
		$this->load->view('main_v',$data);
	}

	public function save_student()
	{
		$data = array();
		$result = $this->dashboard_m->save_student();
		$sdata = array();
		if ($result==1) {
			$sdata['message']='<span style="color:green">Data saved</span>';
			$this->session->set_userdata($sdata);
			redirect('dashboard/new_student');
		}
		else{
			$sdata['message']='<span style="color:red">Data not saved</span>';
			$this->session->set_userdata($sdata);
			redirect('dashboard/new_student');
		}
	}

	public function students()
	{	$data = array();
		$data['title'] = "Dashboard | Students";
		$data['page_title'] = "All Students";
		$config['base_url'] = base_url('dashboard/students');
		$config['per_page'] = 20;
		$config['total_rows'] = $this->db->get('students')->num_rows();
		$this->pagination->initialize($config);
		$data['students'] = $this->dashboard_m->students($config['per_page'],$this->uri->segment(3));
		$data['content'] = $this->load->view('students_v',$data,true);
		$this->load->view('main_v',$data);
	}
	public function single_student($id=null)
	{
		if ($id) {
			$data = array();
			$data['title'] = "Dashboard | Student details";
			$data['page_title'] = "Student details";
			
			$data['student'] = $this->dashboard_m->single_student($id);
			$data['content'] = $this->load->view('single_student_v',$data,true);
			$this->load->view('main_v',$data);
		}
		else{
			redirect('dashboard/students');
		}
	}
	public function edit_student($id=null){
		if ($id) {
			$data = array();
			$data['title'] = "Dashboard | Edit student";
			$data['page_title'] = "Edit student";
			$data['student'] = $this->dashboard_m->edit_student($id);
			$data['courses'] = $this->dashboard_m->courses();
			$data['content'] = $this->load->view('edit_student_v',$data,true);
			$this->load->view('main_v',$data);
		}
		else{
			redirect('dashboard/courses');
		}
	}
	public function update_student($id=null){
		if ($id) {
			$data = array();
			$result = $this->dashboard_m->update_student($id);
			$sdata = array();
			if ($result==1) {
				$sdata['message']='<span style="color:green">Data saved</span>';
				$this->session->set_userdata($sdata);
				redirect('dashboard/students');
			}
			else{
				$sdata['message']='<span style="color:red">Data not saved</span>';
				$this->session->set_userdata($sdata);
				redirect('dashboard/students');
			}
			$this->load->view('main_v',$data);
		}
		else{
			redirect('dashboard/students');
		}
	}
	public function delete_student($id=null)
	{
		if ($id) {
			$sdata= array();
			$image=$this->dashboard_m->single_student($id);
			$result=$this->dashboard_m->delete_student($id,$image);
			if ($result==1) {
				$sdata['message']='Data deleted';
				$this->session->set_userdata($sdata);
				redirect('dashboard/students');
			}
			else{
				$sdata['message']='Data cant\'be deleted';
				$this->session->set_userdata($sdata);
				redirect('dashboard/students');
			}
		}
		else{
			redirect('dashboard/students');
		}
	}
	
	public function print_id_card($id=null)
	{	$data = array();
		$data['student'] = $this->dashboard_m->single_student($id);
		$this->load->view('print_v',$data);
	}

	public function logout()
	{
		$this->session->unset_userdata('user');
		redirect('login');
	}
}


?>