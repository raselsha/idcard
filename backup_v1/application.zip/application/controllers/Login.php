<?php 

defined('BASEPATH') OR exit('No direct script access allowed');



/**

* 

*/

class Login extends CI_Controller

{

	function __construct()

	{

		parent::__construct();

		if ($this->session->has_userdata('user')=='admin'){

			redirect('dashboard');

			

		}

		

	}

	



	public function index()

	{

		

		$data = array();

		$data['title'] = 'Login';

		$data['content'] = $this->load->view('login_v',$data,true);

		$this->load->view('main_v',$data);

	}

	public function check_login()

	{

		$user = $this->input->post('user',true);

		$password = $this->input->post('password',true);



		if ($user == 'admin' and $password == '123') {

			$sdata = array();

			$sdata['user'] = $user; 

			$this->session->set_userdata($sdata);

			redirect('dashboard');



		}

		else{

			redirect('login');

		}

	}



}



?>