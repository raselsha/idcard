<h2><?php echo $page_title; ?></h2>



<p>

<?php 

$message = $this->session->userdata('message');

if ($message) {

	echo $message;

	$this->session->unset_userdata('message');

}

?>

	

</p>

<form method="post" action="<?php echo base_url();  ?>

dashboard/save_student"  enctype="multipart/form-data">

	<fieldset>

		<legend>New student</legend>

		<table style="width:55%;" >

			<tr>

				<td><label>Name</label></td>

				<td><input type="text" name="name"  required="required"></td>

			</tr>

			<tr>

				<td><label>Student Id</label></td>

				<td><input type="text" name="student_id"  required="required"></td>

			</tr>

			<tr>

				<td><label>Mobile</label></td>

				<td><input type="text" name="mobile"  required="required"></td>

			</tr>

			<tr>

				<td><label>Program</label></td>

				<td>

					<select name="course_id" required="required">

						<option value="">Select course</option>

						<?php foreach ($courses as $course) {

						echo '<option value="'.$course->id.'">'.$course->course_name.'</option>';

						} ?>

					</select>

				</td>

			</tr>

			<tr>

				<td><label>Batch</label></td>

				<td><input type="text" name="batch"  required="required"></td>

			</tr>

			<tr>

				<td><label>Validity</label></td>

				<td><input type="text" name="validity" value="Aug-Dec,16" ></td>

			</tr>

			<tr>

				<td><label>Present Address</label></td>

				<td><textarea name="present_address"  required="required"></textarea></td>

			</tr>

			<tr>

				<td><label>Permanant Address</label></td>

				<td><textarea name="permanent_address"  required="required"></textarea></td>

			</tr>

			<tr>

				<td><label>Emergency</label></td>

				<td><input type="text" name="emergency"  required="required"></td>

			</tr>

			<tr>

				<td><label>NID</label></td>

				<td><input type="text" name="nid"></td>

			</tr>

			<tr>

				<td><label>BID</label></td>

				<td><input type="text" name="bid"></td>

			</tr>

			<tr>

				<td><label>Blood</label></td>

				<td><input type="text" name="blood"></td>

			</tr>

			<tr>

				<td><label>Image</label></td>

				<td><input type="file" name="image" ></td>

			</tr>

			<tr>

				<td></td>

				<td><input type="submit" name="submit" value="submit"></td>

				

			</tr>

		</table>

	</fieldset>

</form>

<p><?= anchor('dashboard/students','Back',['class'=>'btn']) ?></p>