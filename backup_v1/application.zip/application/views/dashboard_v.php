<h2><?php echo $page_title; ?></h2>



<div class="box">
	<div class="divider">
		<a href="<?php echo base_url('dashboard/courses') ?>"><img src="<?= base_url('images/courses.png')  ?>"></a>
	</div>
	<a href="<?php echo base_url('dashboard/new_course') ?>" class="btn">New course</a>
</div>



<div class="box">
<a href="<?php echo base_url('dashboard/students') ?>" class="divider"><img src="<?= base_url('images/students.png')  ?>"></a>
	<a href="<?php echo base_url('dashboard/new_student'); ?>" class="btn">New student</a>

</div>



