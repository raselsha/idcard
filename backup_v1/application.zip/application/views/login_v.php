
	<form method="post" action="<?php echo base_url(); ?>login/check_login">
		<fieldset>
			<legend>Login</legend>
			<table style="width:40%;padding:10px;">
				<tr>
					<td><label>User</label></td>
					<td><input type="text" name="user"></td>
				</tr>
				<tr>
					<td><label>Password</label></td>
					<td><input type="password" name="password"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="submit" value="Login"></td>
				</tr>
			</table>
		</fieldset>
	</form>

