<h2><?php echo $page_title; ?></h2>

<p>

<?php 

$message = $this->session->userdata('message');

if ($message) {

	echo $message;

}



?>

	

</p>

<form method="post" action="<?php echo base_url().'dashboard/update_course/'.$course->id;  ?>

"  >

	<fieldset>

		<legend><?php echo $page_title; ?></legend>

		<table style="width:55%;" >

			<tr>

				<td><label>Course Name</label></td>

				<td><input type="text" name="course_name" value="<?php echo $course->course_name; ?>" ></td>

			</tr>

			<tr>

				<td><label>Course Code</label></td>

				<td><input type="text" name="course_code"  value="<?php echo $course->course_code; ?>"></td>

			</tr>

			<tr>

				<td><label>Course Content</label></td>

				<td><textarea name="course_content"  ><?php echo $course->course_content; ?></textarea></td>

			</tr>	

			<tr>

				<td></td>

				<td><input type="submit" name="submit" value="submit"></td>

				

			</tr>

		</table>

	</fieldset>

</form>
<p><?= anchor('dashboard/courses','Back',['class'=>'btn']) ?></p>

