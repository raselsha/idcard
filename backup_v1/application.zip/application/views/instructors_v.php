<h2><?php echo $page_title; ?></h2>

<table width="55%">
<tr>
	<th>Sl</th>
	<th>Name</th>
	<th>Mobile</th>
	<th>Email</th>
	<th>Spciality</th>
	<th>Action</th>
</tr>
<?php 
	
	$sl=$this->uri->segment(3);
	if ($this->uri->segment(3)==0) {
		$sl=1;
	}
	foreach ($instructors as $instructor) {

		echo '<tr>';
		echo '<td>'.$sl++.'</td>';
		echo '<td><a href="'.base_url().'dashboard/single_instructor/'.$instructor->id.'">'.$instructor->instructor_name.'</a></td>';
		echo '<td>'.$instructor->instructor_mobile.'</td>';
		echo '<td>'.$instructor->instructor_email.'</td>';
		echo '<td>'.$instructor->instructor_speciality.'</td>';
		echo '<td><a href="'.base_url().'dashboard/edit_instructor/'.$instructor->id.'">Edit</a></td>';
		echo '<td><a href="'.base_url().'dashboard/delete_instructor/'.$instructor->id.'">Delete</a></td>';
		echo '<tr>';
		echo '<tr>';

	}
 ?>
 </table>
<div class="pagination">
	<?= $this->pagination->create_links(); ?>
</div>