<!DOCTYPE html>
<html>
<head>

	<title><?php echo $title; ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/main.css">

</head>

<body>

	<div class="page">

		<div class="header">

			<h2>ID Card Generator</h2>

			<p><?php echo date('d M, Y'); ?>
				
			</p>

		</div>

		<div class="menu">

		<?php $this->load->view('menu'); ?>

		</div>

		<div class="container">
		
			<?php print $content; ?>

		</div>

	</div>

</body>

</html>