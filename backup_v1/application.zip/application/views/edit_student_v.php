<h2><?php echo $page_title; ?></h2>
<p>
<?php 
$message = $this->session->userdata('message');
if ($message) {
	echo $message;
	$this->session->unset_userdata('message');
}
?>
	
</p>
<form method="post" action="<?php echo base_url().'dashboard/update_student/'.$student->id;  ?>
"  enctype="multipart/form-data">
	<fieldset>
		<legend>New student</legend>
		<table style="width:55%;" >
			<tr>
				<td><label>Name</label></td>
				<td><input type="text" name="name" value="<?php echo $student->name; ?>" required></td>
			</tr>
			<tr>
				<td><label>Student Id</label></td>
				<td><input type="text" name="student_id"  value="<?php echo $student->student_id; ?>" required></td>
			</tr>
			<tr>
				<td><label>Mobile</label></td>
				<td><input type="text" name="mobile" value="<?php echo $student->mobile; ?>" required></td>
			</tr>
			<tr>
				<td><label>Program</label></td>
				<td>
					<select name="course_id" required>
						<option value="">Select course</option>
						<?php foreach ($courses as $course) {
							if ($student->course_id==$course->id) {
								echo '<option value="'.$course->id.'" selected>'.$course->course_name.'</option>';
							}
							else{
								echo '<option value="'.$course->id.'">'.$course->course_name.'</option>';
							}
						} ?>
					</select>
				</td>
			</tr>
			<tr>
				<td><label>Batch</label></td>
				<td><input type="text" name="batch" value="<?php echo $student->batch; ?>" required></td>
			</tr>
			<tr>
				<td><label>Validity</label></td>
				<td><input type="text" name="validity" value="<?php echo $student->validity; ?>" required></td>
			</tr>
			<tr>
				<td><label>Present Address</label></td>
				<td><textarea name="present_address" required><?php echo $student->present_address; ?></textarea></td>
			</tr>
			<tr>
				<td><label>Permanant Address</label></td>
				<td><textarea name="permanent_address" required><?php echo $student->permanent_address; ?></textarea></td>
			</tr>
			<tr>
				<td><label>Emergency</label></td>
				<td><input type="text" name="emergency" value="<?php echo $student->emergency; ?>" required></td>
			</tr>
			<tr>
				<td><label>NID</label></td>
				<td><input type="text" name="nid" value="<?php echo $student->nid; ?>" ></td>
			</tr>
			<tr>
				<td><label>BID</label></td>
				<td><input type="text" name="bid" value="<?php echo $student->bid; ?>"></td>
			</tr>
			<tr>
				<td><label>Blood</label></td>
				<td><input type="text" name="blood" value="<?php echo $student->blood; ?>"></td>
			</tr>
			<tr>
				<td><label>Image</label></td>
				<td><input type="file" name="image" ></td>
				<input type="hidden" name="photo" value="<?php echo $student->image; ?>">
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="submit"></td>
				
			</tr>
		</table>
	</fieldset>
</form>
<p><?= anchor('dashboard/students','Back',['class'=>'btn']) ?></p>
