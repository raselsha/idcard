<!DOCTYPE html>

<html>

<head>

	<title>Id Card</title>

	<meta charset="utf-8">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/print.css" media="print">

	<?php if ($student->course_id==7) : ?>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/print_voc.css" media="print">
	<?php endif; ?>
	<script>
		function printarea() {
		    window.print();
		}
	</script>

</head>

<body>

	<div class="container">

		<div id="id_card">

			<div class="id_card" >

				<div class="id_header">

					<div class="id_logo">

						<img src="<?php echo base_url(); ?>images/logo.png">

					</div>

					<h4>

						Runner Cyberlink Limited

					</h4>

					<div class="id_photo">

					<?php 

						$image =$student->id.'_'.$student->image;

						if (file_exists('images/students/'.$image)) {

							$image = base_url().'images/students/'.$student->id.'_'.$student->image;

							echo '<img src="'.$image.'">';

						}

						else{

							$image = base_url().'images/students/profile.png';

							echo '<img src="'.$image.'">';

						}

					 ?>

					</div>

				</div>

				

				<div class="id_content">

					<div class="id_text">

						<table>

							<tr>

								<td>Name</td>

								<td>:</td>

								<td><?php echo $student->name; ?></td>

							</tr>

							<tr>

								<td>Id No</td>

								<td>:</td>

								<td><?php echo $student->student_id; ?></td>

							</tr>

							<tr>

								<td>Program</td>

								<td>:</td>
								
								<td><?php echo $student->course_name; ?></td>

							</tr>

							<tr>

								<td>Batch</td>

								<td>:</td>

								<td><?php echo $student->batch; ?></td>

							</tr>

							<tr>

								<td>Validity</td>

								<td>:</td>

								<td>Aug - Dec, 2016</td>

							</tr>

						</table>

					</div>

				</div>

				<div class="id_signature">

					<span>Authorized Signature</span>

				</div>
				<div class="id_footer">

					<p>STUDENT</p>

				</div>
			</div>



			<div class="id_card_bk" >

				<div class="id_card_content">

					<div class="id_card_bk_left">

						<div class="address">

							<h2>Present Address</h2>

							<p>

								<?php echo $student->present_address; ?>

							</p>

						</div>

						<div class="address">

							<h2>Permanent Address</h2>

							<p><?php echo $student->permanent_address; ?>

							</p>

						</div>

						<div class="address">

							<p><strong>Emergency</strong> :  <?php echo $student->emergency; ?></p>

							<p><strong>NID</strong> : <?php echo $student->nid; ?></p>

							<p><strong>Blood</strong> : <span style="color:red"><?php echo $student->blood; ?></span></p>

						</div>



					</div>

					<div class="id_card_bk_right">

						<div class="address">

							<h2>Corporate Office</h2>

							<p>13/5 Aurungzeb Road,<br>

								Nagar Nirupoma (2nd floor)<br> 

								Mohammadpur, Dhaka 1207

							</p>

						</div>

						<div class="address">

							<h2>Branch Office</h2>

							<p>

								9/1,Shah Ali Bagh<br>

								Label 5,Mirpur-1<br>

								Dhaka

							</p>

						</div>

						<div class="address">

							<h2>Contact</h2>

							<p>Tel : 02-58152764<br>

							   Tel : 02-9007619<br>

							   Cell: 01724790402<br>

							</p>

						</div>

					</div>

				</div>

				<div class="id_card_footer">

					<p>www.runnercyberlink.com</p>

				</div>

			</div>

		</div>

		<center><button onclick="printarea()">Print</button></center>

	</div>

	<script language="Javascript">

	</script>

</body>

</html>